var app = new Vue({
  el: '#app',
  data: {
   checkedFlag:0,
   gradeOrder:false,
   timeOrder:false,
   testList:[
		{
      grades:100,
      title:'关于宠物营养的随堂测试1',
      detail:'课程：我们一直在努力推动宠物营养前进',
      date:'2017年2月5日'
    },{
			grades:89,
			title:'关于宠物营养的随堂测试2',
			detail:'课程：我们一直在努力推动宠物营养前进',
			date:'2016年2月5日'
		},
		{
			grades:70,
			title:'关于宠物营养的随堂测试3',
			detail:'课程：如何促进猫星人的健康体重？',
			date:'2017年5月5日'
		},
		{
			grades:0,
			title:'关于宠物营养的随堂测试4',
			detail:'课程：如何促进猫星人的健康体重？',
			date:'2017年6月6日'
		},
	]
  },
  mounted: function () {
  	this.$nextTick(function(){
	     //this.selectOrderWay();
  	});
  },
  methods: {
  	selectOrderWay:function(checkedFlag){
      this.checkedFlag = checkedFlag;
  		/*if(typeof item.checked == 'undefined'){
        Vue.set(item, "checked", true); //全局注册
        //this.$set(item, "checked", true); //局部注册
      }else{
          item.checked = !item.checked;
      }*/
      if (checkedFlag == 1) {
        var orderFlag = this.gradeOrder;
        this.testList.sort(function(obj1,obj2){
          if (orderFlag) {
            return obj1.grades - obj2.grades
          }else{
            return obj2.grades - obj1.grades
          }
        });
        this.gradeOrder = !this.gradeOrder;
      }
      else if (checkedFlag ==  2) {
        var timeOrder = this.timeOrder;
        this.testList.sort(function(obj1,obj2){
          var dateYear1 = obj1.date.split("年")[0];
          var dateYear2 = obj2.date.split("年")[0];
          if (dateYear1 == dateYear2) {
            var month1 = (obj1.date.split("年")[1]).split("月")[0];
            var month2 = (obj2.date.split("年")[1]).split("月")[0];
            if (month1 == month2) {
                var day1 = (obj1.date.split("月")[1]).split("日")[0];
                var day2 = (obj2.date.split("月")[1]).split("日")[0];
                if (timeOrder) {
                  return month1 - month2
                }
                else{
                  return month2 - month1
                }
            }else{
              if (timeOrder) {
                return month1 - month2
              }
              else{
                return month2 - month1
              }
            }
          }else{
            if (timeOrder) {
              return dateYear1 - dateYear2
            }
            else{
              return dateYear2 - dateYear1
            }
          }
        });

        this.timeOrder = !this.timeOrder;
      }
  	}
  }
});